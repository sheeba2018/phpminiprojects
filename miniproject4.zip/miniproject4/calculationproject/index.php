<?php
include 'Calculator.php';

$calc=new Calculator();
$number1=""; 
$number2="";
$answer="";
if(isset($_POST['num1'])&& isset($_POST['num2']))
{
    $number1=$_POST['num1'];
    $number2=$_POST['num2'];
    $flag = true;
     
    $oper=$_POST['selectaoperator'];
    if(is_numeric($number1)&& is_numeric($number2)){
        switch($oper){
            case 'add':
                $oper='+';
                break;
            case 'sub':
                $oper='-';
                break;
            case 'multi':
                $oper='*';
                break;
            case 'div':
                $oper='/';
                break;
            default:
                $flag=false;
                $answer="please select an operator";
        }
        if($flag)
            $answer=$calc->calc($oper, $number1, $number2);

   }
   else
   {
       $answer="please enter only number";
   }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>&lt;My Web Page&gt;</title>
	<style>
	
</style>

	
</head>
<body>
    <form action="" method="post">
        <select name="selectaoperator">
            <option value="select">Select a Operator</option>
            <option value="add">Add</option>
            <option value="sub">Subtraction</option>
            <option value="multi">Multiply</option>
            <option value="div">Division</option>
        </select>
        <br/>
        <p>Enter First Number</p>
        <input type="text" name="num1"/>
        <br/>
        <p>Enter Second Number</p>
        <input type="text" name="num2"/>
        <br/>
        <input type="submit"  name="submit" value="Calculate Numbers"/>
        
    </form>
<?php
echo "Answer: ".$answer;

?>	

</body>
</html>	


